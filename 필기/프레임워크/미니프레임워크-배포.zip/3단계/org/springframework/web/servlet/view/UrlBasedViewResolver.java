package org.springframework.web.servlet.view;

public class UrlBasedViewResolver {
	public static final String REDIRECT_URL_PREFIX = "redirect:";
}
